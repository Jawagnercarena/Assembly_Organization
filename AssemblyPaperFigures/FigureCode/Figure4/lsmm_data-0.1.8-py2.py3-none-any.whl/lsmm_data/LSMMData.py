import json
import os
import numpy as np
import pandas
import scipy
from lsmm_data import cell_filters
import re
from tqdm import tqdm
import math
import networkx as nx

# A class to load and map between various tables and arrays for Large-Scale Multimodal (LSMM) data sets like MICrONS mm3 and v1 deepdive
class LSMMData:
    def __init__(self, loaded_json=None):
        if loaded_json is not None:
            self.params = self.get_params(loaded_json)
            self.dirs = self.get_dirs(self.params)
            self.data = self.get_data(self.params, self.dirs)
            self.mappings = self.get_mappings(self.params, self.dirs, self.data)

    def get_data_objects(self):
        return self.params, self.dirs, self.data, self.mappings

    def __repr__(self):
        return self.params #(f'Run Info:\n\n{self.params}\n\n{self.dirs}\n\n{self.tables}\n\n{self.mappings}')
    def __str__(self):
        return self.params #f'Run Info:\n\n{self.params}\n\n{self.dirs}\n\n{self.tables}\n\n{self.mappings}'
    
    def set_params(self, param_dict):
        # To do: add mutators for all the get_params parameters
        self.dirs = self.get_dirs(self.params)

    def get_params(self, loaded_json):
        params = {}
        # params['sigma'] = int(loaded_json['sigma'])
        params['dataset'] = loaded_json['dataset']
        params['run_descriptor'] = loaded_json['run_descriptor']
        if 'structural_data_version' in loaded_json.keys():
            params['structural_data_version'] = loaded_json['structural_data_version']
        elif params['dataset'] == 'v1dd': 
            params['structural_data_version'] = 742
        elif params['dataset'] == 'MICrONS':
            params['structural_data_version'] = 943

        if 'data_directory' in loaded_json.keys():
            params['data_directory'] = loaded_json['data_directory']
        else:
            params['data_directory'] = 'data_files'

        if 'region_list' in loaded_json.keys():
            params['region_list'] = loaded_json['region_list']
        else:
            params['region_list'] = []

        if 'session' in loaded_json.keys():
            params['session'] = loaded_json['session']
        elif params['dataset'] == 'v1dd': 
            params['session'] = 1
        elif params['dataset'] == 'MICrONS':
            params['session_scan_list'] = 4

        if 'scan' in loaded_json.keys():
            params['scan'] = loaded_json['scan']
        elif params['dataset'] == 'v1dd': 
            params['scan'] = 3
        elif params['dataset'] == 'MICrONS':
            params['scan'] = 7

        if 'affinity' in loaded_json.keys():
            params['affinity'] = loaded_json['affinity']
        else:
            params['affinity'] = 4

        if 'quintile_cross_validation' in loaded_json.keys():
            params['quintile_cross_validation'] = int(loaded_json['quintile_cross_validation'])
        else:
            params['quintile_cross_validation'] = False

        if 'use_functional_data' in loaded_json.keys():
            params['use_functional_data'] = bool(loaded_json['use_functional_data'])
        else:
            params['use_functional_data'] = False

        if 'use_sgc_assemblies' in loaded_json.keys():
            params['use_sgc_assemblies'] = bool(loaded_json['use_sgc_assemblies'])
        else:
            params['use_sgc_assemblies'] = False

        if 'use_structural_data' in loaded_json.keys():
            params['use_structural_data'] = bool(loaded_json['use_structural_data'])
        else:
            params['use_structural_data'] = False

        if 'calc_connectomes' in loaded_json.keys():
            params['calc_connectomes'] = bool(loaded_json['calc_connectomes'])
        else:
            params['calc_connectomes'] = False

        if 'functional_data_version' in loaded_json.keys():
            params['functional_data_version'] = loaded_json['functional_data_version']
        else:
            params['functional_data_version'] = 'final'

        if 'require_postsynaptic_axon_proofreading' in loaded_json.keys():
            params['proofread_to_proofread'] = bool(loaded_json['require_postsynaptic_axon_proofreading'])
        elif 'proofread_to_proofread' in loaded_json.keys():
            params['proofread_to_proofread'] = bool(loaded_json['proofread_to_proofread'])
        else:
            params['proofread_to_proofread'] = False

        if 'pyramidal_by_layer' in loaded_json.keys():
            params['pyramidal_by_layer'] = bool(loaded_json['pyramidal_by_layer'])
        else:
            params['pyramidal_by_layer'] = False

        if 'inhibitory_by_layer' in loaded_json.keys():
            params['inhibitory_by_layer'] = bool(loaded_json['inhibitory_by_layer'])
        else:
            params['inhibitory_by_layer'] = False

        if 'coarse_excitatory' in loaded_json.keys():
            params['coarse_excitatory'] = bool(loaded_json['coarse_excitatory'])
        else:
            params['coarse_excitatory'] = False
    
        if 'coarse_inhibitory' in loaded_json.keys():
            params['coarse_inhibitory'] = bool(loaded_json['coarse_inhibitory'])
        else:
            params['coarse_inhibitory'] = False

        if 'pyramidal_only' in loaded_json.keys():
            params['pyramidal_only'] = bool(loaded_json['pyramidal_only'])
        else:
            params['pyramidal_only'] = False

        if 'excitatory_only' in loaded_json.keys():
            params['excitatory_only'] = bool(loaded_json['excitatory_only'])
        else:
            params['excitatory_only'] = False

        if 'filter_min_cells_by_type' in loaded_json.keys():
            params['filter_min_cells_by_type'] = int(loaded_json['filter_min_cells_by_type'])
        else:
            params['filter_min_cells_by_type'] = None

        if 'root_ids_to_exclude' in loaded_json.keys():
            params['root_ids_to_exclude'] = loaded_json['root_ids_to_exclude']
        else:
            params['root_ids_to_exclude'] = []
        
        return params

    def get_dirs(self, params):
        dirs = {}
        dirs['main'] = f"{params['dataset']}_{params['run_descriptor']}"
        dirs['data'] = params['data_directory']
        if params['use_structural_data'] == True:
            dirs['structural_data'] = f"{dirs['data']}/{params['dataset']}/structural/{params['structural_data_version']}"
            
        if params['use_functional_data'] == True:
            dirs['functional_data'] = f"{dirs['data']}/{params['dataset']}/functional/{params['functional_data_version']}"
        
        if params['use_structural_data'] & params['use_functional_data']:
            dirs['coregistration_data'] = f"{dirs['data']}/{params['dataset']}/coregistration"

        return dirs
        
    def _invert_dict(self, original_dict):
        inverted_dict = {}
        for key, items in original_dict.items():
            for item in items:
                if item not in inverted_dict:
                    inverted_dict[item] = [key]
                else:
                    inverted_dict[item].append(key)
        return inverted_dict

    def _map_dict_keys(self, key_mapping_dict, dict_to_update):
        updated_dict = {}
        for key, val in dict_to_update.items():
            new_key = key_mapping_dict.get(key)
            if new_key is None:
                continue
            else:
                updated_dict[new_key] = val
        return updated_dict

    def _get_filenames_starting_with(self, directory_path, prefix):
        # Get a list of all files in the directory
        all_files = os.listdir(directory_path)
        
        # Filter files that start with the specified prefix
        matching_files = [filename for filename in all_files if filename.startswith(prefix)]
        
        return matching_files

    def _find_highest_numbered_file(self, directory, match_string):
        # Get a list of all files in the directory
        files = self._get_filenames_starting_with(directory, match_string)
        print(match_string)
        print(files)

        # Initialize variables to store the highest number and corresponding filename
        highest_number = -1
        highest_numbered_file = None

        # Iterate over each file
        for filename in files:
            # Extract the base filename (without extension)
            base_filename, _ = os.path.splitext(filename)

            # Check if the base filename contains a six-digit number
            match = re.search(r'\d{6}', base_filename)
            if match:
                # Get the numeric value of the six-digit number
                number = int(match.group())

                # Update the highest number and filename if necessary
                if number > highest_number:
                    highest_number = number
                    highest_numbered_file = filename

        return highest_numbered_file
   
    def get_mappings(self, params, dirs, data):
        mappings = {}
        
        if params['use_sgc_assemblies']:
            # # Get the functional indexes of neurons involved in each assembly
            # # STEFAN REWORK OF JULIAN EDIT: Compose assembly names one-indexed, and zero-index the assembly functional indexes, which start at one in the matlab file
            mappings['functional_indexes_by_assembly'] = {}
            all_assembly_functional_indexes = []
            # print(data['functional']['sgc_assemblies']['assemblies'])
            for assembly_idx in range(len(data['functional']['sgc_assemblies']['assemblies'])):
                one_indexed_temp = list(np.subtract(data['functional']['sgc_assemblies']['assemblies'][assembly_idx], 1))
                mappings['functional_indexes_by_assembly'][f'A {assembly_idx+1}'] = one_indexed_temp
                # print(one_indexed_temp)
                all_assembly_functional_indexes += one_indexed_temp
            session = params['session']
            scan = params['scan']
            affinity = params['affinity']
            mappings['functional_indexes_by_assembly']['No A'] = list(set(range(data['functional'][f'Scan {session}-{scan}']['f'].shape[1])) - set(all_assembly_functional_indexes))
            mappings['assemblies_by_functional_index'] = self._invert_dict(mappings['functional_indexes_by_assembly'])

        if params['use_structural_data']:
            # print(data['structural']['post_cell'])
            connectome_index_to_root_id_mapping = dict(data['structural']['pre_cell'][['connectome_index', 'pt_root_id']].values)
            root_id_to_connectome_index_mapping = dict(data['structural']['pre_cell'][['pt_root_id', 'connectome_index']].values)
            mappings['pt_root_id_to_connectome_index'] = root_id_to_connectome_index_mapping
            mappings['connectome_index_to_root_id'] = connectome_index_to_root_id_mapping
            post_connectome_index_to_root_id_mapping = dict(data['structural']['post_cell'][['connectome_index', 'pt_root_id']].values)
            root_id_to_post_connectome_index_mapping = dict(data['structural']['post_cell'][['pt_root_id', 'connectome_index']].values)
            mappings['pt_root_id_to_post_connectome_index'] = root_id_to_post_connectome_index_mapping
            mappings['post_connectome_index_to_root_id'] = post_connectome_index_to_root_id_mapping
        if params['use_structural_data'] and params['use_functional_data']:
            roi_id_to_pt_root_id_mapping = dict(data['coregistration'][['roi_id', 'pt_root_id']].values)
            mappings['roi_id_to_pt_root_id'] = roi_id_to_pt_root_id_mapping
            mappings['pt_root_id_to_roi_id'] = dict(data['coregistration'][['pt_root_id', 'roi_id']].values)
            roi_id_temp = pandas.DataFrame(np.load(f'{dirs["functional_data"]}/sessionM409828_13_roi_id_by_index.npy'))
            roi_id_temp['functional_index'] = roi_id_temp.index
            roi_id_temp['roi_id'] = roi_id_temp[0]
            roi_id_temp['roi_id'] = roi_id_temp['roi_id'].apply(lambda x: x[0:5] + str(int(x[5])+1) + x[6:])
            functional_index_to_roi_id_mapping = dict(roi_id_temp[['functional_index', 'roi_id']].values)
            mappings['roi_id_to_functional_index'] = dict(roi_id_temp[['roi_id', 'functional_index']].values)
        if params['use_structural_data'] and params['use_functional_data'] and params['use_sgc_assemblies']:
            # Construct a mapping from the functional index to the roi_id
            mappings['functional_index_to_roi_id'] = functional_index_to_roi_id_mapping
            mappings['assemblies_by_roi_id'] = self._map_dict_keys(key_mapping_dict=functional_index_to_roi_id_mapping, dict_to_update=mappings['assemblies_by_functional_index'] )
            mappings['assemblies_by_pt_root_id'] = self._map_dict_keys(key_mapping_dict=roi_id_to_pt_root_id_mapping, dict_to_update=mappings['assemblies_by_roi_id'])
            mappings['assemblies_by_connectome_index'] = self._map_dict_keys(key_mapping_dict=root_id_to_connectome_index_mapping, dict_to_update=mappings['assemblies_by_pt_root_id'])
            # mappings['assemblies_by_connectome_index'] = self._map_dict_keys(key_mapping_dict=root_id_to_connectome_index_mapping, dict_to_update=mappings['assemblies_by_pt_root_id'])
            mappings['assemblies_by_post_connectome_index'] = self._map_dict_keys(key_mapping_dict=root_id_to_post_connectome_index_mapping, dict_to_update=mappings['assemblies_by_pt_root_id'])
            mappings['connectome_indexes_by_assembly'] = self._invert_dict(mappings['assemblies_by_connectome_index'])
            mappings['post_connectome_indexes_by_assembly'] = self._invert_dict(mappings['assemblies_by_post_connectome_index'])
            mappings['pt_root_ids_by_assembly'] = self._invert_dict(mappings['assemblies_by_pt_root_id'])
            mappings['roi_ids_by_assembly'] = self._invert_dict(mappings['assemblies_by_roi_id'])
        return mappings

    def calc_ground_truth(self, pre_cells, synapse, post_cells, use_sizes=False):
        if use_sizes:
            print('Generating Summed PSD Volume Connectome...')
        else:
            print('Generating Synapse Count Connectome...')
        
        # Merge synapse with pre_cells and post_cells to get connectome_index
        synapse = synapse.merge(pre_cells[['pt_root_id', 'connectome_index']], left_on='pre_pt_root_id', right_on='pt_root_id', how='inner')
        synapse = synapse.merge(post_cells[['pt_root_id', 'connectome_index']], left_on='post_pt_root_id', right_on='pt_root_id', how='inner')

        # Create a directed graph from the merged DataFrame
        if use_sizes:
            temp_graph = nx.from_pandas_edgelist(synapse, 'connectome_index_x', 'connectome_index_y', 'size', create_using=nx.DiGraph())
        else:
            temp_graph = nx.from_pandas_edgelist(synapse, 'connectome_index_x', 'connectome_index_y', create_using=nx.DiGraph())
        
        # Ensure all nodes from pre_cells are included in the graph
        for node in pre_cells['connectome_index']:
            if not temp_graph.has_node(node):
                temp_graph.add_node(node)

        # Convert the graph to a numpy array
        connectome = nx.to_numpy_array(temp_graph, dtype=int)
        
        if len(post_cells) != len(pre_cells):
            # Identify rows corresponding to nodes listed in pre_cells
            pre_cell_indices = pre_cells['connectome_index'].to_numpy()
            
            # Remove rows not listed in pre_cells
            non_square_connectome = connectome[pre_cell_indices, :]
            
            return non_square_connectome
        else:
            return connectome

        
    # def calc_ground_truth_old(self, pre_cells, synapse, post_cells, use_sizes=False):
    #     print('Generating Connectome...')
    #     total_synapse_count = 0
    #     pre_cell_pt_index = pre_cells['pt_root_id']
    #     post_cell_pt_index = post_cells['pt_root_id']
    #     synapses = synapse[(synapse['pre_pt_root_id'].isin(pre_cells['pt_root_id'])) & (synapse['post_pt_root_id'].isin(post_cells['pt_root_id']))]
    #     pre_cell_pt_index = pre_cell_pt_index.to_list()
    #     post_cell_pt_index = post_cell_pt_index.to_list()

    #     synapse_connectome = np.zeros((len(pre_cells), len(post_cells)))
    #     for synapse in tqdm(range(len(synapses))):
    #         preidx = pre_cell_pt_index.index(synapses.iloc[synapse]['pre_pt_root_id'])
    #         postidx = post_cell_pt_index.index(synapses.iloc[synapse]['post_pt_root_id'])
    #         if use_sizes:
    #             synapse_connectome[preidx,postidx] += synapses.iloc[synapse]['size']
    #         else:
    #             synapse_connectome[preidx,postidx] += 1
    #         total_synapse_count += 1
    #     return synapse_connectome

    def get_data(self, params, dirs):
        data = {}
        # Load Structural data if we are using it
        if self.params['use_structural_data'] == True:
            data['structural'] = {}
            cell_file = self._find_highest_numbered_file(dirs['structural_data'], f'{self.params["dataset"]}_cell')
            print(cell_file[0])
            original_cell_table = pandas.read_feather(f"{dirs['structural_data']}/{cell_file}")
            original_cell_table = original_cell_table.sort_values('cell_type_v2').reset_index()
            
            if params['proofread_to_proofread']:
                data['structural']['post_cell'] = cell_filters.proofread_filter(original_cell_table).reset_index(drop=True)
            else:
                data['structural']['post_cell'] = original_cell_table
            data['structural']['pre_cell'] = cell_filters.proofread_filter(original_cell_table).reset_index(drop=True)
            if params['coarse_excitatory']:
                print('Coarse-Typing Excitatory Cells')
                data['structural']['pre_cell'] = cell_filters.coarse_excitatory_filter(data['structural']['pre_cell'])
                data['structural']['post_cell'] = cell_filters.coarse_excitatory_filter(data['structural']['post_cell'])
                print(len(data['structural']['pre_cell']))
            if params['coarse_inhibitory']:
                print('Coarse-Typing Inhibitory Cells')
                data['structural']['pre_cell'] = cell_filters.coarse_inhibitory_filter(data['structural']['pre_cell'])
                data['structural']['post_cell'] = cell_filters.coarse_inhibitory_filter(data['structural']['post_cell'])
                print(len(data['structural']['pre_cell']))
            print(data['structural']['pre_cell']['cell_type_v2'].value_counts())
            if params['pyramidal_only']:
                print('Filtering to pyramidal cells only')
                data['structural']['pre_cell'] = cell_filters.pyramidal_only_filter(data['structural']['pre_cell'])
                data['structural']['post_cell'] = cell_filters.pyramidal_only_filter(data['structural']['post_cell'])
                print(len(data['structural']['pre_cell']))
            if params['filter_min_cells_by_type'] is not None:
                print(f'Filtering to {params["filter_min_cells_by_type"]} cells per type')
                data['structural']['pre_cell'] = cell_filters.at_least_n_cells_by_type(data['structural']['pre_cell'], params['filter_min_cells_by_type'])
                data['structural']['post_cell'] = cell_filters.at_least_n_cells_by_type(data['structural']['post_cell'], params['filter_min_cells_by_type'])
                print(len(data['structural']['pre_cell']))
            if len(params['root_ids_to_exclude']) > 0:
                print(f'Excluding {len(params["root_ids_to_exclude"])} root ids')
                data['structural']['pre_cell'] = cell_filters.exclude_root_ids(data['structural']['pre_cell'], params['root_ids_to_exclude'])
                data['structural']['post_cell'] = cell_filters.exclude_root_ids(data['structural']['post_cell'], params['root_ids_to_exclude'])
                print(len(data['structural']['pre_cell']))
            if len(params['region_list']) > 0:
                print(f'Filtering to regions: {params["region_list"]}')
                data['structural']['pre_cell'] = cell_filters.filter_by_regions(data['structural']['pre_cell'], params['region_list'])
                data['structural']['post_cell'] = cell_filters.filter_by_regions(data['structural']['post_cell'], params['region_list'])
                print(len(data['structural']['pre_cell']))
            data['structural']['pre_cell']['index'].rename('full_cell_table_index', inplace=True)
            data['structural']['post_cell']['index'].rename('full_cell_table_index', inplace=True)
            # if params['quintile_cross_validation']:
            #     data['structural']['full_pre_cell'] = data['structural']['pre_cell'].copy()
            #     data['structural']['full_post_cell'] = data['structural']['post_cell'].copy()
            #     data['structural']['pre_cell'] = data['structural']['full_pre_cell'].loc[data['structural']['pre_cell']['cell_type_CV_axon'] > 0]
            #     data['structural']['post_cell'] = data['structural']['full_post_cell'].loc[data['structural']['post_cell']['cell_type_CV_dendrite'] > 0]
                # data['structural']['pre_cell_test'] = data['structural']['full_pre_cell'].loc[data['structural']['full_pre_cell']['cell_type_CV_axon'] == 1].reset_index(drop=True, inplace=True)
                # data['structural']['post_cell_test'] = data['structural']['full_post_cell'].loc[data['structural']['full_post_cell']['cell_type_CV_dendrite'] == 1].reset_index(drop=True, inplace=True)

            data['structural']['pre_cell'].reset_index(drop=True, inplace=True)
            data['structural']['post_cell'].reset_index(drop=True, inplace=True)

            data['structural']['pre_cell']['connectome_index'] = data['structural']['pre_cell'].index
            data['structural']['post_cell']['connectome_index'] = data['structural']['post_cell'].index
            # if params['quintile_cross_validation']:
            #     data['structural']['pre_cell_test']['connectome_index'] = data['structural']['pre_cell_test'].index
            #     data['structural']['post_cell_test']['connectome_index'] = data['structural']['post_cell_test'].index

            synapse_file = self._find_highest_numbered_file(dirs['structural_data'], 'synapses')

            data['structural']['synapse'] = pandas.read_feather(f"{dirs['structural_data']}/{synapse_file}")
            # if params['dataset'] == 'v1dd':
            #     data['structural']['synapse'] = data['structural']['synapse'] * (9 * 9 * 45)
            # if params['dataset'] == 'MICrONS':
            #     data['structural']['synapse'] = data['structural']['synapse'] * (4 * 4 * 40)

            # Remove Autapses
            data['structural']['synapse'] = data['structural']['synapse'].drop(
                data['structural']['synapse'][data['structural']['synapse']['pre_pt_root_id'] == data['structural']['synapse']['post_pt_root_id']].index)

            # Remove synapses not between our pre and post cells
            data['structural']['synapse'] = data['structural']['synapse'].loc[
                data['structural']['synapse']['post_pt_root_id'].isin(data['structural']['post_cell']['pt_root_id'])]
            data['structural']['synapse'] = data['structural']['synapse'].loc[
                data['structural']['synapse']['pre_pt_root_id'].isin(data['structural']['pre_cell']['pt_root_id'])]
            data['structural']['synapse'].reset_index(drop=True, inplace=True)     

            # Create combined position columns
            data['structural']['pre_cell']['pt_position'] = [[data['structural']['pre_cell'].iloc[i]['pt_position_x'],data['structural']['pre_cell'].iloc[i]['pt_position_y'],data['structural']['pre_cell'].iloc[i]['pt_position_z']] for i in range(len(data['structural']['pre_cell']))]
            data['structural']['post_cell']['pt_position'] = [[data['structural']['post_cell'].iloc[i]['pt_position_x'],data['structural']['post_cell'].iloc[i]['pt_position_y'],data['structural']['post_cell'].iloc[i]['pt_position_z']] for i in range(len(data['structural']['post_cell']))]
            data['structural']['synapse']['ctr_pt_position'] = list(np.array(data['structural']['synapse'][['pt_position_x_trafo', 'pt_position_y_trafo', 'pt_position_z_trafo']]))

            if self.params['calc_connectomes'] == True:
                if params['quintile_cross_validation']:
                    data['structural']['synapse_count_connectome'] = self.calc_ground_truth(data['structural']['pre_cell_test'], data['structural']['synapse'], data['structural']['post_cell_test'], use_sizes=False)
                    data['structural']['binary_connectome'] = data['structural']['synapse_count_connectome'].clip(0,1)
                    data['structural']['summed_size_connectome'] = self.calc_ground_truth(data['structural']['pre_cell_test'], data['structural']['synapse'], data['structural']['post_cell_test'], use_sizes=True)
                    data['structural']['averaged_size_connectome'] = np.zeros_like(data['structural']['synapse_count_connectome'], dtype=float)
                    data['structural']['averaged_size_connectome'][data['structural']['synapse_count_connectome'] > 0] = data['structural']['summed_size_connectome'][data['structural']['synapse_count_connectome'] > 0] / data['structural']['synapse_count_connectome'][data['structural']['synapse_count_connectome'] > 0]
                else:
                    data['structural']['synapse_count_connectome'] = self.calc_ground_truth(data['structural']['pre_cell'], data['structural']['synapse'], data['structural']['post_cell'], use_sizes=False)
                    # temp = self.calc_ground_truth_old(data['structural']['pre_cell'], data['structural']['synapse'], data['structural']['post_cell'], use_sizes=False)
                    # print("Connectome Diff:", np.max(data['structural']['synapse_count_connectome'] - temp))
                    data['structural']['binary_connectome'] = data['structural']['synapse_count_connectome'].clip(0,1)
                    data['structural']['summed_size_connectome'] = self.calc_ground_truth(data['structural']['pre_cell'], data['structural']['synapse'], data['structural']['post_cell'], use_sizes=True)
                    data['structural']['averaged_size_connectome'] = np.zeros_like(data['structural']['synapse_count_connectome'], dtype=float)
                    data['structural']['averaged_size_connectome'][data['structural']['synapse_count_connectome'] > 0] = data['structural']['summed_size_connectome'][data['structural']['synapse_count_connectome'] > 0] / data['structural']['synapse_count_connectome'][data['structural']['synapse_count_connectome'] > 0]

        # Load Functional data if we are using it
        if self.params['use_functional_data'] == True:
            data['functional'] = {}
            data['functional']['sgc_assemblies'] = {}
            animal_identifier = ''
            if params['dataset'] == 'v1dd':
                animal_identifier = 'M409828'
            elif params['dataset'] == 'MICrONS':
                animal_identifier = 'M409828'
            else:
                animal_identifier = 'ERROR'

            # for session_scan in self.params['session_scan_list']:
            session = params['session']
            scan = params['scan']
            affinity = params['affinity']
            data['functional'][f'Scan {session}-{scan}'] = {}
            data['functional'][f'Scan {session}-{scan}']['f'] = np.load(f"{dirs['functional_data']}/session{animal_identifier}_{session}{scan}_f.npy")
            data['functional'][f'Scan {session}-{scan}']['dff'] = np.load(f"{dirs['functional_data']}/session{animal_identifier}_{session}{scan}_dff.npy")
            data['functional'][f'Scan {session}-{scan}']['events'] = np.load(f"{dirs['functional_data']}/session{animal_identifier}_{session}{scan}_events.npy")
            data['functional'][f'Scan {session}-{scan}']['roi_by_index'] = np.load(f"{dirs['functional_data']}/session{animal_identifier}_{session}{scan}_roi_id_by_index.npy")
            if params['dataset'] == 'MICrONS':
                area_membership = np.load(f"dirs['functional_data']/IARPA_session{session}_scan{scan}_area_membership.npy")
            else:
                area_membership = np.array(['VisP' for i in range(data['functional'][f'Scan {session}-{scan}']['f'].shape[0])])
            data['functional'][f'Scan {session}-{scan}']['area_membership'] = area_membership
            # # Load assembly and coregistration data, and create useful mappings
            SGC_ASSEMBLIES = scipy.io.loadmat(f"{dirs['functional_data']}/esteps_150000_affinity_0{affinity}_session{animal_identifier}_{session}{scan}_SGC-ASSEMBLIES.mat", struct_as_record=True, squeeze_me=True)
            ### JULIAN EDIT: REORDER ASSEMBLIES
            ordered_assemblies = sorted(SGC_ASSEMBLIES["assemblies"], key = len)
            ordered_assemblies.reverse()
            SGC_ASSEMBLIES['assemblies'] = ordered_assemblies
            data['functional']['sgc_assemblies'] = SGC_ASSEMBLIES
                
        # Load Coregistration data if we are using both structural and functional
        if self.params['use_structural_data'] == True & self.params['use_functional_data'] == True: 
            coregistration_table = pandas.read_feather(f"{dirs['data']}/v1dd/coregistration/coregistration_table.feather")
            # Construct ROI IDs and make a mapping to pt_root_ids
            coregistration_table['roi_id'] = [f"plane{coregistration_table['field'].values[i]}_roi_{coregistration_table['unit_id'].values[i]:04d}" for i in range(len(coregistration_table))]
            data['coregistration'] = coregistration_table

        return data