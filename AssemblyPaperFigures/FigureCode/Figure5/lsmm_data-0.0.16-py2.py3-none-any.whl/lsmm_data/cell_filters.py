import pandas
import numpy as np

def proofread_filter(cell_table):
    # Restrict to fully extended proofread axons
    cell_table = cell_table[cell_table['status_axon'] == 'extended']
    return cell_table

def pyramidal_only_filter(cell_table):
    cell_table = cell_table[cell_table['classification_system'] == 'excitatory']
    return cell_table

def coarse_excitatory_filter(cell_table):
    cell_table[cell_table['classification_system'] == 'excitatory']['cell_type_v2'] = 'E'
    return cell_table

def coarse_inhibitory_filter(cell_table):
    cell_table[cell_table['classification_system'] == 'inhibitory']['cell_type_v2'] = 'I'
    return cell_table

def common_type_mapping_filter(cell_table):
    return cell_table

def at_least_n_cells_by_type(cell_table, n=10):
    cell_table = cell_table.groupby('cell_type_v2').filter(lambda x: len(x) >= n)
    return cell_table

def exclude_root_ids(cell_table, root_ids):
    cell_table = cell_table[~cell_table['pt_root_id'].isin(root_ids)]
    return cell_table