import json
import os
import numpy as np
import pandas
import scipy
from lsmm_data import cell_filters
import re
from tqdm import tqdm
import math

# # From https://github.com/perrygeo/pairing/
# def pair(k1, k2, safe=True):
#     """
#     Cantor pairing function
#     http://en.wikipedia.org/wiki/Pairing_function#Cantor_pairing_function
#     """
#     z = int(0.5 * (k1 + k2) * (k1 + k2 + 1) + k2)
#     if safe and (k1, k2) != depair(z):
#         raise ValueError("{} and {} cannot be paired".format(k1, k2))
#     return z

# def depair(z):
#     """
#     Inverse of Cantor pairing function
#     http://en.wikipedia.org/wiki/Pairing_function#Inverting_the_Cantor_pairing_function
#     """
#     w = math.floor((math.sqrt(8 * z + 1) - 1)/2)
#     t = (w**2 + w) / 2
#     y = int(z - t)
#     x = int(w - y)
#     # assert z != pair(x, y, safe=False):
#     return x, y

# A class to load and map between various tables and arrays for Large-Scale Multimodal (LSMM) data sets like MICrONS mm3 and v1 deepdive
class LSMMData:
    def __init__(self, loaded_json=None):
        if loaded_json is not None:
            self.params = self.get_params(loaded_json)
            self.dirs = self.get_dirs(self.params)
            self.data = self.get_data(self.params, self.dirs)
            self.mappings = self.get_mappings(self.params, self.dirs, self.data)

    def get_all(self):
        return self.params, self.dirs, self.data, self.mappings

    def __repr__(self):
        return self.params #(f'Run Info:\n\n{self.params}\n\n{self.dirs}\n\n{self.tables}\n\n{self.mappings}')
    def __str__(self):
        return self.params #f'Run Info:\n\n{self.params}\n\n{self.dirs}\n\n{self.tables}\n\n{self.mappings}'
    
    def set_params(self, param_dict):
        # To do: add mutators for all the get_params parameters
        self.dirs = self.get_dirs(self.params)

    def get_params(self, loaded_json):
        params = {}
        # params['sigma'] = int(loaded_json['sigma'])
        params['dataset'] = loaded_json['dataset']
        params['run_descriptor'] = loaded_json['run_descriptor']
        if 'structural_data_version' in loaded_json.keys():
            params['structural_data_version'] = loaded_json['structural_data_version']
        elif params['dataset'] == 'v1dd': 
            params['structural_data_version'] = 742
        elif params['dataset'] == 'MICrONS':
            params['structural_data_version'] = 943

        if 'region_list' in loaded_json.keys():
            params['region_list'] = loaded_json['region_list']
        else:
            params['region_list'] = ['visP']

        if 'session_scan_list' in loaded_json.keys():
            params['session_scan_list'] = loaded_json['session_scan_list']
        elif params['dataset'] == 'v1dd': 
            params['session_scan_list'] = [(1,3)]
        elif params['dataset'] == 'MICrONS':
            params['session_scan_list'] = [(4,7)]

        if 'use_functional_data' in loaded_json.keys():
            params['use_functional_data'] = bool(loaded_json['use_functional_data'])
        else:
            params['use_functional_data'] = False

        if 'use_sgc_assemblies' in loaded_json.keys():
            params['use_sgc_assemblies'] = bool(loaded_json['use_sgc_assemblies'])
        else:
            params['use_sgc_assemblies'] = False

        if 'use_structural_data' in loaded_json.keys():
            params['use_structural_data'] = bool(loaded_json['use_structural_data'])
        else:
            params['use_structural_data'] = False

        if 'calc_connectomes' in loaded_json.keys():
            params['calc_connectomes'] = bool(loaded_json['calc_connectomes'])
        else:
            params['calc_connectomes'] = False

        if 'functional_data_version' in loaded_json.keys():
            params['functional_data_version'] = loaded_json['functional_data_version']
        else:
            params['functional_data_version'] = 'final'

        if 'proofread_to_proofread' in loaded_json.keys():
            params['proofread_to_proofread'] = bool(loaded_json['proofread_to_proofread'])
        else:
            params['proofread_to_proofread'] = False

        if 'pyramidal_by_layer' in loaded_json.keys():
            params['pyramidal_by_layer'] = bool(loaded_json['pyramidal_by_layer'])
        else:
            params['pyramidal_by_layer'] = False

        if 'inhibitory_by_layer' in loaded_json.keys():
            params['inhibitory_by_layer'] = bool(loaded_json['inhibitory_by_layer'])
        else:
            params['inhibitory_by_layer'] = False

        if 'coarse_excitatory' in loaded_json.keys():
            params['coarse_excitatory'] = bool(loaded_json['coarse_excitatory'])
        else:
            params['coarse_excitatory'] = False
    
        if 'coarse_inhibitory' in loaded_json.keys():
            params['coarse_inhibitory'] = bool(loaded_json['coarse_inhibitory'])
        else:
            params['coarse_inhibitory'] = False

        if 'pyramidal_only' in loaded_json.keys():
            params['pyramidal_only'] = bool(loaded_json['pyramidal_only'])
        else:
            params['pyramidal_only'] = False

        if 'filter_min_cells_by_type' in loaded_json.keys():
            params['filter_min_cells_by_type'] = int(loaded_json['filter_min_cells_by_type'])
        else:
            params['filter_min_cells_by_type'] = None

        if 'root_ids_to_exclude' in loaded_json.keys():
            params['root_ids_to_exclude'] = loaded_json['root_ids_to_exclude']
        else:
            params['root_ids_to_exclude'] = []
        
        return params

    def get_dirs(self, params):
        dirs = {}
        dirs['main'] = f"{params['dataset']}_{params['run_descriptor']}"
        dirs['data'] = f'data_files'
        if params['use_structural_data'] == True:
            dirs['structural_data'] = f"{dirs['data']}/{params['dataset']}/structural/{params['structural_data_version']}"
            
        if params['use_functional_data'] == True:
            dirs['functional_data'] = f"{dirs['data']}/{params['dataset']}/functional/{params['functional_data_version']}"
        
        if params['use_structural_data'] & params['use_functional_data']:
            dirs['coregistration_data'] = f"{dirs['data']}/{params['dataset']}/coregistration/{params['functional_data_version']}"

        return dirs
        
    def _invert_dict(self, original_dict):
        inverted_dict = {}
        for key, items in original_dict.items():
            for item in items:
                if item not in inverted_dict:
                    inverted_dict[item] = [key]
                else:
                    inverted_dict[item].append(key)
        return inverted_dict

    def _map_dict_keys(self, key_mapping_dict, dict_to_update):
        updated_dict = {}
        for key, val in dict_to_update.items():
            new_key = key_mapping_dict.get(key)
            if new_key is None:
                continue
            else:
                updated_dict[new_key] = val
        return updated_dict

    def _get_filenames_starting_with(self, directory_path, prefix):
        # Get a list of all files in the directory
        all_files = os.listdir(directory_path)
        
        # Filter files that start with the specified prefix
        matching_files = [filename for filename in all_files if filename.startswith(prefix)]
        
        return matching_files

    def _find_highest_numbered_file(self, directory, match_string):
        # Get a list of all files in the directory
        files = self._get_filenames_starting_with(directory, match_string)

        # Initialize variables to store the highest number and corresponding filename
        highest_number = -1
        highest_numbered_file = None

        # Iterate over each file
        for filename in files:
            # Extract the base filename (without extension)
            base_filename, _ = os.path.splitext(filename)

            # Check if the base filename contains a six-digit number
            match = re.search(r'\d{6}', base_filename)
            if match:
                # Get the numeric value of the six-digit number
                number = int(match.group())

                # Update the highest number and filename if necessary
                if number > highest_number:
                    highest_number = number
                    highest_numbered_file = filename

        return highest_numbered_file
   
    def get_mappings(self, params, dirs, data):
        mappings = {}
        
        if params['use_sgc_assemblies']:
            # # Get the functional indexes of neurons involved in each assembly
            # # STEFAN REWORK OF JULIAN EDIT: Compose assembly names one-indexed, and zero-index the assembly functional indexes, which start at one in the matlab file
            mappings['functional_indexes_by_assembly'] = {}
            all_assembly_functional_indexes = []
            # print(data['functional']['sgc_assemblies']['assemblies'])
            for assembly_idx in range(len(data['functional']['sgc_assemblies']['assemblies'])):
                one_indexed_temp = list(np.subtract(data['functional']['sgc_assemblies']['assemblies'][assembly_idx], 1))
                mappings['functional_indexes_by_assembly'][f'A {assembly_idx+1}'] = one_indexed_temp
                # print(one_indexed_temp)
                all_assembly_functional_indexes += one_indexed_temp
            session, scan = params['session_scan_list'][0]
            mappings['functional_indexes_by_assembly']['No A'] = list(set(range(data['functional'][f'Scan {session}-{scan}']['f'].shape[1])) - set(all_assembly_functional_indexes))
            mappings['assemblies_by_functional_index'] = self._invert_dict(mappings['functional_indexes_by_assembly'])

        if params['use_structural_data']:
            # print(data['structural']['post_cell'])
            connectome_index_to_root_id_mapping = dict(data['structural']['post_cell'][['connectome_index', 'pt_root_id']].values)
            root_id_to_connectome_index_mapping = dict(data['structural']['post_cell'][['pt_root_id', 'connectome_index']].values)
            mappings['pt_root_id_to_connectome_index'] = root_id_to_connectome_index_mapping
            mappings['connectome_index_to_root_id'] = connectome_index_to_root_id_mapping
        if params['use_structural_data'] and params['use_functional_data']:
            roi_id_to_pt_root_id_mapping = dict(data['coregistration'][['roi_id', 'pt_root_id']].values)
        if params['use_structural_data'] and params['use_functional_data'] and params['use_sgc_assemblies']:
            # Construct a mapping from the functional index to the roi_id
            roi_id_temp = pandas.DataFrame(np.load(f'{dirs["functional_data"]}/sessionM409828_13_roi_id_by_index.npy'))
            roi_id_temp['functional_index'] = roi_id_temp.index
            roi_id_temp['roi_id'] = roi_id_temp[0]
            roi_id_temp['roi_id'] = roi_id_temp['roi_id'].apply(lambda x: x[0:5] + str(int(x[5])+1) + x[6:])
            functional_index_to_roi_id_mapping = dict(roi_id_temp[['functional_index', 'roi_id']].values)
            mappings['roi_id_to_pt_root_id'] = roi_id_to_pt_root_id_mapping
            mappings['functional_index_to_roi_id'] = functional_index_to_roi_id_mapping
            mappings['assemblies_by_roi_id'] = self._map_dict_keys(key_mapping_dict=functional_index_to_roi_id_mapping, dict_to_update=mappings['assemblies_by_functional_index'] )
            mappings['assemblies_by_pt_root_id'] = self._map_dict_keys(key_mapping_dict=roi_id_to_pt_root_id_mapping, dict_to_update=mappings['assemblies_by_roi_id'])
            mappings['assemblies_by_connectome_index'] = self._map_dict_keys(key_mapping_dict=root_id_to_connectome_index_mapping, dict_to_update=mappings['assemblies_by_pt_root_id'])
            mappings['connectome_indexes_by_assembly'] = self._invert_dict(mappings['assemblies_by_connectome_index'])
            mappings['pt_root_ids_by_assembly'] = self._invert_dict(mappings['assemblies_by_pt_root_id'])
            mappings['roi_ids_by_assembly'] = self._invert_dict(mappings['assemblies_by_roi_id'])
        return mappings

    # def calc_ground_truth_two(self, pre_cells, synapse, post_cells, use_sizes=False):
    #     print('Matching synapse dataframe to pre_cells and post_cells...')
    #     synapse = synapse.merge(pre_cells[['pt_root_id', 'connectome_index']], left_on='pre_pt_root_id', right_on='pt_root_id', how='inner')
    #     synapse = synapse.merge(post_cells[['pt_root_id', 'connectome_index']], left_on='post_pt_root_id', right_on='pt_root_id', how='inner')
        
    #     print('Generating Connectome...')
    #     pre_cell_indexes = synapse['connectome_index_x'].to_numpy()
    #     # max_post_index = 
    #     post_cell_indexes = synapse['connectome_index_y'].to_numpy()
    #     # synapse_counts_and_sizes = synapse[['index_x', 'index_y']].groupby(['index_x', 'index_y']).apply(lambda x: x).reset_index(drop = True)
    #     # synapse_counts_and_sizes['unique_pre_post_values'] = synapse_counts_and_sizes[['index_x', 'index_y']]))
    #     # temp_counts = synapse_counts_and_sizes.value_counts()
    #     # synapse_counts_and_sizes['count'] = synapse_counts_and_sizes['pre_post_indexes'].map(temp_counts)
        
    #     # synapse_counts_and_sizes['summed_sizes'] = synapse.groupby(['index_x', 'index_y'])['size'].transform('sum')
    #     # summed_sizes = synapse[['index_x', 'index_y']].value_counts()
    #     # # temp_pre_post_index_array = np.dstack((a,b))
    #     # pre_post_index_array = np.column_stack((pre_cell_indexes,post_cell_indexes))
    #     cantors = [pair(pre_cell_indexes[i], post_cell_indexes[i]) for i in range(len(pre_cell_indexes))]
    #     synapse_counts = np.bincount(cantors, minlength=pre_cell_indexes.size)
    #     synapse_counts = synapse_counts.reshape(len(pre_cells), len(post_cells))
        
    #     synapse_sizes = synapse['size'].to_numpy()
    #     synapse_sizes = np.bincount(pre_cell_indexes * len(post_cells) + post_cell_indexes, weights=synapse_sizes, minlength=len(pre_cells) * len(post_cells))
    #     synapse_sizes = synapse_sizes.reshape(len(pre_cells), len(post_cells))
    #     connectome = np.stack((synapse_counts, synapse_sizes), axis=-1)
        
    #     return connectome

    def calc_ground_truth(self, pre_cells, synapse, post_cells, use_sizes=False):
        print('Generating Connectome...')
        total_synapse_count = 0
        pre_cell_pt_index = pre_cells['pt_root_id']
        post_cell_pt_index = post_cells['pt_root_id']
        synapses = synapse[(synapse['pre_pt_root_id'].isin(pre_cells['pt_root_id'])) & (synapse['post_pt_root_id'].isin(post_cells['pt_root_id']))]
        pre_cell_pt_index = pre_cell_pt_index.to_list()
        post_cell_pt_index = post_cell_pt_index.to_list()

        synapse_connectome = np.zeros((len(pre_cells), len(post_cells)))
        for synapse in tqdm(range(len(synapses))):
            preidx = pre_cell_pt_index.index(synapses.iloc[synapse]['pre_pt_root_id'])
            postidx = post_cell_pt_index.index(synapses.iloc[synapse]['post_pt_root_id'])
            if use_sizes:
                synapse_connectome[preidx,postidx] += synapses.iloc[synapse]['size']
            else:
                synapse_connectome[preidx,postidx] += 1
            total_synapse_count += 1
        return synapse_connectome

    def get_data(self, params, dirs):
        data = {}
        # Load Structural data if we are using it
        if self.params['use_structural_data'] == True:
            data['structural'] = {}
            cell_file = self._find_highest_numbered_file(dirs['structural_data'], f'{self.params["dataset"]}_cell')
            if params['proofread_to_proofread']:
                data['structural']['post_cell'] = cell_filters.proofread_filter(pandas.read_feather(f"{dirs['structural_data']}/{cell_file}")).reset_index()
            else:
                data['structural']['post_cell'] = pandas.read_feather(f"{dirs['structural_data']}/{cell_file}")
            data['structural']['pre_cell'] = cell_filters.proofread_filter(pandas.read_feather(f"{dirs['structural_data']}/{cell_file}")).reset_index()
            if params['coarse_excitatory']:
                data['structural']['pre_cell'] = cell_filters.coarse_excitatory_filter(data['structural']['pre_cell'])
                data['structural']['post_cell'] = cell_filters.coarse_excitatory_filter(data['structural']['post_cell'])
            if params['coarse_inhibitory']:
                data['structural']['pre_cell'] = cell_filters.coarse_inhibitory_filter(data['structural']['pre_cell'])
                data['structural']['post_cell'] = cell_filters.coarse_inhibitory_filter(data['structural']['post_cell'])
            if params['pyramidal_only']:
                data['structural']['pre_cell'] = cell_filters.pyramidal_only_filter(data['structural']['pre_cell'])
                data['structural']['post_cell'] = cell_filters.pyramidal_only_filter(data['structural']['post_cell'])
            if params['filter_min_cells_by_type'] is not None:
                print(f'Filtering to {params["filter_min_cells_by_type"]} cells per type')
                data['structural']['pre_cell'] = cell_filters.at_least_n_cells_by_type(data['structural']['pre_cell'], params['filter_min_cells_by_type'])
                data['structural']['post_cell'] = cell_filters.at_least_n_cells_by_type(data['structural']['post_cell'], params['filter_min_cells_by_type'])
            if params['root_ids_to_exclude']:
                data['structural']['pre_cell'] = cell_filters.exclude_root_ids(data['structural']['pre_cell'], params['root_ids_to_exclude'])
                data['structural']['post_cell'] = cell_filters.exclude_root_ids(data['structural']['post_cell'], params['root_ids_to_exclude'])
            data['structural']['pre_cell'].reset_index(drop=True, inplace=True)
            data['structural']['post_cell'].reset_index(drop=True, inplace=True)
            data['structural']['pre_cell']['index'].rename('full_cell_table_index', inplace=True)
            data['structural']['post_cell']['index'].rename('full_cell_table_index', inplace=True)
            data['structural']['pre_cell']['connectome_index'] = data['structural']['pre_cell'].index
            data['structural']['post_cell']['connectome_index'] = data['structural']['post_cell'].index
            synapse_file = self._find_highest_numbered_file(dirs['structural_data'], 'synapses')

            data['structural']['synapse'] = pandas.read_feather(f"{dirs['structural_data']}/{synapse_file}")

            # Remove Autapses
            data['structural']['synapse'] = data['structural']['synapse'].drop(
                data['structural']['synapse'][data['structural']['synapse']['pre_pt_root_id'] == data['structural']['synapse']['post_pt_root_id']].index)
            # Remove synapses not targeting any of our postsynaptic cells
            data['structural']['synapse'] = data['structural']['synapse'].loc[
                data['structural']['synapse']['post_pt_root_id'].isin(data['structural']['post_cell']['pt_root_id'])]
            data['structural']['synapse'] = data['structural']['synapse'].loc[
                data['structural']['synapse']['pre_pt_root_id'].isin(data['structural']['post_cell']['pt_root_id'])]
            data['structural']['synapse'].reset_index(drop=True, inplace=True)     

            # Create combined position columns
            data['structural']['pre_cell']['pt_position'] = [[data['structural']['pre_cell'].iloc[i]['pt_position_x'],data['structural']['pre_cell'].iloc[i]['pt_position_y'],data['structural']['pre_cell'].iloc[i]['pt_position_z']] for i in range(len(data['structural']['pre_cell']))]
            data['structural']['post_cell']['pt_position'] = [[data['structural']['post_cell'].iloc[i]['pt_position_x'],data['structural']['post_cell'].iloc[i]['pt_position_y'],data['structural']['post_cell'].iloc[i]['pt_position_z']] for i in range(len(data['structural']['post_cell']))]
            data['structural']['synapse']['ctr_pt_position'] = list(np.array(data['structural']['synapse'][['pt_position_x_trafo', 'pt_position_y_trafo', 'pt_position_z_trafo']]))

            if self.params['calc_connectomes'] == True:
                data['structural']['synapse_count_connectome'] = self.calc_ground_truth(data['structural']['pre_cell'], data['structural']['synapse'], data['structural']['post_cell'], use_sizes=False)
                data['structural']['binary_connectome'] = data['structural']['synapse_count_connectome'].clip(0,1)
                data['structural']['summed_size_connectome'] = self.calc_ground_truth(data['structural']['pre_cell'], data['structural']['synapse'], data['structural']['post_cell'], use_sizes=True)
                

        # Load Functional data if we are using it
        if self.params['use_functional_data'] == True:
            data['functional'] = {}
            data['functional']['sgc_assemblies'] = {}
            animal_identifier = ''
            if params['dataset'] == 'v1dd':
                animal_identifier = 'M409828'
            elif params['dataset'] == 'MICrONS':
                animal_identifier = 'M409828'
            else:
                animal_identifier = 'ERROR'

            for session_scan in self.params['session_scan_list']:
                session, scan = session_scan
                data['functional'][f'Scan {session}-{scan}'] = {}
                data['functional'][f'Scan {session}-{scan}']['f'] = np.load(f"{dirs['functional_data']}/session{animal_identifier}_{session}{scan}_f.npy")
                data['functional'][f'Scan {session}-{scan}']['dff'] = np.load(f"{dirs['functional_data']}/session{animal_identifier}_{session}{scan}_dff.npy")
                data['functional'][f'Scan {session}-{scan}']['events'] = np.load(f"{dirs['functional_data']}/session{animal_identifier}_{session}{scan}_events.npy")
                data['functional'][f'Scan {session}-{scan}']['roi_by_index'] = np.load(f"{dirs['functional_data']}/session{animal_identifier}_{session}{scan}_roi_id_by_index.npy")
                if params['dataset'] == 'MICrONS':
                    area_membership = np.load(f"dirs['functional_data']/IARPA_session{session}_scan{scan}_area_membership.npy")
                else:
                    area_membership = np.array(['VisP' for i in range(data['functional'][f'Scan {session}-{scan}']['f'].shape[0])])
                data['functional'][f'Scan {session}-{scan}']['area_membership'] = area_membership
                # # Load assembly and coregistration data, and create useful mappings
                SGC_ASSEMBLIES = scipy.io.loadmat(f"{dirs['functional_data']}/esteps_150000_affinity_04_session{animal_identifier}_{session}{scan}_SGC-ASSEMBLIES.mat", struct_as_record=True, squeeze_me=True)
                ### JULIAN EDIT: REORDER ASSEMBLIES
                ordered_assemblies = sorted(SGC_ASSEMBLIES["assemblies"], key = len)
                ordered_assemblies.reverse()
                SGC_ASSEMBLIES['assemblies'] = ordered_assemblies
                data['functional']['sgc_assemblies'] = SGC_ASSEMBLIES
                
        # Load Coregistration data if we are using both structural and functional
        if self.params['use_structural_data'] == True & self.params['use_functional_data'] == True: 
            coregistration_table = pandas.read_feather(f"data_files/v1dd/coregistration/coregistration_table.feather")
            # Construct ROI IDs and make a mapping to pt_root_ids
            coregistration_table['roi_id'] = [f"plane{coregistration_table['field'].values[i]}_roi_{coregistration_table['unit_id'].values[i]:04d}" for i in range(len(coregistration_table))]
            data['coregistration'] = coregistration_table

        return data